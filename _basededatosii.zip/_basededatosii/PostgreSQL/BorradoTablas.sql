-- LOS DROPS DEBEN HACERSE EN ESE ORDEN POR INTEGRIDAD REFERENCIAL

drop table Recompensas_Contacto;
drop table Recompensas_Influencia;
drop table Recompensas_Dinero;
drop table PropiedadesUsadas;
drop table ProporcionarApoyo;
drop table objetivos;
drop table eventos;
drop table ritos;
drop table sersolocontacto;
drop table tratos;
drop table armas;
drop table vehiculos;
drop table almacenes;
drop table inmobiliario;
drop table commodities;
drop table cuentas;
drop table propiedades;
drop table contactos;
drop table guia_espiritual;
drop table gestor_interno;
drop table miembros_basicos;
drop table jefes_de_division;
drop table cabecillas;
drop table acólitos;
