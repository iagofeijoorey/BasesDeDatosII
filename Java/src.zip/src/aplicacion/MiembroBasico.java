package aplicacion;

/**
 *
 * @author basesdatos
 */

/*
public class MiembroBasico extends Acolito {
    private JefeDivision jefe;

   public MiembroBasico(String idUsuario, String clave, String nombre, String direccion, String email, int influencia, JefeDivision jefe){
       super(idUsuario, clave, nombre, direccion, email, influencia, (tipoAcolito) Normal);
        this.jefe = jefe;
   }

   //Getter

    public JefeDivision getJefe() {
        return jefe;
    }

    //Setter
    public void setJefe (JefeDivision jefe) {
        this.jefe = jefe;
    }

}
*/
